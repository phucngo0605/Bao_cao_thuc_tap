# AdnLog Query Server

Server API để truy vấn số lượng user view/click từ dữ liệu AdnLog.

## Cài đặt và chạy

```bash
# Cài đặt dependencies
pip install -r requirements.txt

# Cấp quyền thực thi
chmod +x start_server.sh test_api.sh

# Chạy server (development)
./start_server.sh dev

# Chạy server (production)
./start_server.sh
```

## API Endpoints

- `GET /` - API documentation
- `GET /health` - Health check
- `GET /query` - Query user count

### Query Parameters

- `id_type`: `campaignId` hoặc `bannerId`
- `id`: ID của campaign/banner
- `mode`: `click` hoặc `view`
- `from`: Ngày bắt đầu (YYYY-MM-DD)
- `to`: Ngày kết thúc (YYYY-MM-DD)

### Example

```bash
curl "http://localhost:5000/query?id_type=campaignId&id=12345&mode=view&from=2024-07-01&to=2024-07-05"
```

## Test

```bash
./test_api.sh
```