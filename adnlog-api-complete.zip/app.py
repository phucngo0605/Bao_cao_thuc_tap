from flask import Flask, request, jsonify
from datetime import datetime
import logging
import os
import sys

from spark_session import get_spark
from data_processor import AdnLogProcessor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'adnlog-secret-key-2024')

# Global variables
spark = None
processor = None

def init_app():
    """Initialize Spark session and load data"""
    global spark, processor
    try:
        logger.info("=== Starting AdnLog Server Initialization ===")
        
        logger.info("Step 1: Initializing Spark session...")
        spark = get_spark()
        logger.info("✓ Spark session created successfully")
        
        logger.info("Step 2: Initializing data processor...")
        processor = AdnLogProcessor(spark)
        logger.info("✓ Data processor initialized")
        
        logger.info("Step 3: Loading and caching data from HDFS...")
        if processor.load_and_cache_data():
            logger.info("✓ Data loaded and cached successfully")
            logger.info("=== Server initialization completed ===")
            return True
        else:
            logger.error("✗ Failed to load data")
            return False
            
    except Exception as e:
        logger.error(f"✗ Initialization error: {str(e)}")
        return False

@app.route("/", methods=["GET"])
def home():
    """Home endpoint with API documentation"""
    return jsonify({
        "service": "AdnLog Query API",
        "version": "1.0.0",
        "endpoints": {
            "/health": "Health check",
            "/query": "Query user count for campaign/banner"
        },
        "query_parameters": {
            "id_type": "campaignId or bannerId",
            "id": "Target ID value",
            "mode": "click or view",
            "from": "Start date (YYYY-MM-DD)",
            "to": "End date (YYYY-MM-DD)"
        },
        "example": "/query?id_type=campaignId&id=12345&mode=view&from=2024-07-01&to=2024-07-05"
    })

@app.route("/health", methods=["GET"])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "service": "AdnLog Query API",
        "timestamp": datetime.now().isoformat(),
        "spark_status": "active" if spark else "inactive"
    })

@app.route("/query", methods=["GET"])
def query_user_count():
    """Main query endpoint"""
    start_time = datetime.now()
    
    try:
        # Get parameters
        id_type = request.args.get("id_type")
        target_id = request.args.get("id")
        mode = request.args.get("mode")
        from_date = request.args.get("from")
        to_date = request.args.get("to")
        
        logger.info(f"Received query: id_type={id_type}, id={target_id}, mode={mode}, from={from_date}, to={to_date}")
        
        # Validate required parameters
        if not all([id_type, target_id, mode, from_date, to_date]):
            return jsonify({
                "error": "Missing required parameters",
                "required": ["id_type", "id", "mode", "from", "to"],
                "received": {
                    "id_type": id_type,
                    "id": target_id,
                    "mode": mode,
                    "from": from_date,
                    "to": to_date
                }
            }), 400
        
        # Validate date format
        try:
            datetime.strptime(from_date, '%Y-%m-%d')
            datetime.strptime(to_date, '%Y-%m-%d')
        except ValueError:
            return jsonify({
                "error": "Invalid date format. Use YYYY-MM-DD",
                "example": "2024-07-01"
            }), 400
        
        # Execute query
        logger.info("Executing Spark query...")
        user_count = processor.query_user_count(id_type, target_id, mode, from_date, to_date)
        
        end_time = datetime.now()
        query_time = (end_time - start_time).total_seconds()
        
        logger.info(f"Query completed in {query_time:.3f}s, result: {user_count} users")
        
        return jsonify({
            "success": True,
            "data": {
                "id_type": id_type,
                "id": target_id,
                "mode": mode,
                "from_date": from_date,
                "to_date": to_date,
                "user_count": user_count
            },
            "meta": {
                "query_time_seconds": round(query_time, 3),
                "timestamp": end_time.isoformat()
            }
        })
        
    except Exception as e:
        end_time = datetime.now()
        query_time = (end_time - start_time).total_seconds()
        
        logger.error(f"Query failed after {query_time:.3f}s: {str(e)}")
        return jsonify({
            "success": False,
            "error": str(e),
            "meta": {
                "query_time_seconds": round(query_time, 3),
                "timestamp": end_time.isoformat()
            }
        }), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({
        "error": "Endpoint not found",
        "available_endpoints": ["/", "/health", "/query"]
    }), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({
        "error": "Internal server error",
        "message": "Please check server logs for details"
    }), 500

if __name__ == "__main__":
    print("🚀 Starting AdnLog Query Server...")
    
    if init_app():
        print("✅ Initialization successful!")
        print("🌐 Server starting on http://0.0.0.0:5000")
        print("📖 API Documentation: http://localhost:5000/")
        print("❤️  Health Check: http://localhost:5000/health")
        
        app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
    else:
        print("❌ Failed to initialize application")
        sys.exit(1)