from pyspark.sql.functions import from_unixtime, col, countDistinct, to_date, lit
from pyspark.sql.types import TimestampType, StructType, StructField, StringType, BooleanType, LongType
from datetime import datetime
import logging
import os

logger = logging.getLogger(__name__)

class AdnLogProcessor:
    def __init__(self, spark):
        self.spark = spark
        self.df = None

    def create_sample_data(self):
        """Tạo dữ liệu mẫu cho development"""
        logger.info("Creating sample data for development...")

        # Schema cho dữ liệu mẫu
        schema = StructType([
            StructField("guid", StringType(), True),
            StructField("campaignId", StringType(), True),
            StructField("bannerId", StringType(), True),
            StructField("click_or_view", BooleanType(), True),
            StructField("time_create", LongType(), True)
        ])

        # Dữ liệu mẫu
        sample_data = [
            ("user1", "12345", "banner1", False, 1720137600000),  # 2024-07-05 view
            ("user2", "12345", "banner1", True, 1720137600000),   # 2024-07-05 click
            ("user3", "12345", "banner2", False, 1720051200000),  # 2024-07-04 view
            ("user1", "67890", "banner3", False, 1720051200000),  # 2024-07-04 view
            ("user4", "12345", "banner1", False, 1719964800000),  # 2024-07-03 view
            ("user5", "12345", "banner1", True, 1719964800000),   # 2024-07-03 click
        ]

        # Tạo DataFrame
        df = self.spark.createDataFrame(sample_data, schema)

        # Xử lý timestamp và chọn các cột cần thiết
        df_processed = df.withColumn(
            "event_time",
            from_unixtime(col("time_create") / 1000).cast(TimestampType())
        ).withColumn(
            "event_date",
            to_date(col("event_time"))
        )

        return df_processed

    def load_and_cache_data(self):
        """Nạp và cache dữ liệu AdnLog"""
        try:
            mode = os.environ.get('SPARK_MODE', 'remote')

            if mode in ['remote', 'yarn']:
                logger.info("Loading AdnLog data from HDFS...")
                # Đọc dữ liệu Parquet từ HDFS
                df = self.spark.read.parquet("hdfs://adt-platform-dev-106-254:8120/data/Parquet/AdnLog/*")

                # Xử lý timestamp và chọn các cột cần thiết
                df_processed = df.select(
                    "guid",
                    "campaignId",
                    "bannerId",
                    "click_or_view",
                    col("time_group.time_create").alias("time_create")
                ).withColumn(
                    "event_time",
                    from_unixtime(col("time_create") / 1000).cast(TimestampType())
                ).withColumn(
                    "event_date",
                    to_date(col("event_time"))
                )
            else:
                logger.info("Using sample data for development...")
                df_processed = self.create_sample_data()

            # Cache dữ liệu để truy vấn nhanh
            self.df = df_processed.cache()

            # Trigger action để cache thực sự
            count = self.df.count()
            logger.info(f"Cached {count} records successfully")

            # In ra một vài dòng dữ liệu mẫu (chỉ với dữ liệu nhỏ)
            if mode == 'local':
                logger.info("Sample data:")
                self.df.show(5)
            else:
                logger.info("Data schema:")
                self.df.printSchema()
                logger.info("First few records:")
                self.df.show(3, truncate=False)

            return True

        except Exception as e:
            logger.error(f"Error loading data: {str(e)}")
            return False
    
    def query_user_count(self, id_type, target_id, mode, from_date, to_date):
        """Truy vấn số lượng user unique"""
        try:
            # Validate parameters
            if id_type not in ["campaignId", "bannerId"]:
                raise ValueError("id_type must be 'campaignId' or 'bannerId'")
            
            if mode not in ["click", "view"]:
                raise ValueError("mode must be 'click' or 'view'")
            
            # Convert mode to boolean
            is_click = (mode == "click")
            
            # Build query
            result = self.df.filter(col(id_type) == target_id) \
                           .filter(col("click_or_view") == is_click) \
                           .filter(col("event_date").between(from_date, to_date)) \
                           .agg(countDistinct("guid").alias("user_count")) \
                           .collect()
            
            if result:
                return int(result[0]["user_count"])
            else:
                return 0
                
        except Exception as e:
            logger.error(f"Query error: {str(e)}")
            raise