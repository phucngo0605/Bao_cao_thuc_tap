#!/bin/bash

echo "🚀 AdnLog API - Environment Setup Script"
echo "========================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Step 1: Check system requirements
echo ""
print_info "Step 1: Checking system requirements..."

# Check Python
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
    print_status "Python found: $PYTHON_VERSION"
else
    print_error "Python 3 not found! Please install Python 3.8+"
    exit 1
fi

# Check Java
if command -v java &> /dev/null; then
    JAVA_VERSION=$(java -version 2>&1 | head -n1 | cut -d'"' -f2)
    print_status "Java found: $JAVA_VERSION"
else
    print_error "Java not found! Please install Java 8+"
    exit 1
fi

# Step 2: Find Spark installation
echo ""
print_info "Step 2: Locating Spark installation..."

# Common Spark locations
SPARK_LOCATIONS=(
    "/data/spark-3.4.3"
    "/opt/spark"
    "/usr/local/spark"
    "/home/spark"
    "/spark"
)

SPARK_HOME=""
for location in "${SPARK_LOCATIONS[@]}"; do
    if [ -d "$location" ] && [ -f "$location/bin/spark-submit" ]; then
        SPARK_HOME="$location"
        break
    fi
done

# If not found in common locations, search
if [ -z "$SPARK_HOME" ]; then
    print_warning "Spark not found in common locations. Searching..."
    SPARK_HOME=$(find /opt /usr/local /data /home -name "spark-submit" -type f 2>/dev/null | head -1 | xargs dirname | xargs dirname 2>/dev/null)
fi

if [ -n "$SPARK_HOME" ] && [ -f "$SPARK_HOME/bin/spark-submit" ]; then
    print_status "Spark found at: $SPARK_HOME"
    
    # Get Spark version
    SPARK_VERSION=$($SPARK_HOME/bin/spark-submit --version 2>&1 | grep "version" | head -1 | sed 's/.*version \([0-9.]*\).*/\1/')
    print_status "Spark version: $SPARK_VERSION"
else
    print_error "Spark installation not found!"
    print_info "Please install Spark or set SPARK_HOME manually"
    exit 1
fi

# Step 3: Install Python dependencies
echo ""
print_info "Step 3: Installing Python dependencies..."

if [ -f "requirements.txt" ]; then
    print_info "Installing from requirements.txt..."
    
    # Try pip3 first, then pip
    if command -v pip3 &> /dev/null; then
        pip3 install -r requirements.txt --user
    elif command -v pip &> /dev/null; then
        pip install -r requirements.txt --user
    else
        print_error "pip not found! Please install pip"
        exit 1
    fi
    
    if [ $? -eq 0 ]; then
        print_status "Dependencies installed successfully"
    else
        print_warning "Some dependencies may have failed. Continuing..."
    fi
else
    print_warning "requirements.txt not found. Skipping dependency installation."
fi

# Step 4: Setup environment variables
echo ""
print_info "Step 4: Setting up environment variables..."

# Create environment setup file
cat > .env << EOF
# AdnLog API Environment Configuration
export SPARK_HOME="$SPARK_HOME"
export PATH=\$PATH:\$SPARK_HOME/bin:\$SPARK_HOME/sbin
export PYTHONPATH=\$SPARK_HOME/python:\$SPARK_HOME/python/lib/py4j-*-src.zip:\$PYTHONPATH
export PYSPARK_PYTHON=python3
export SPARK_MODE=local
EOF

print_status "Environment file created: .env"

# Step 5: Set permissions
echo ""
print_info "Step 5: Setting file permissions..."

chmod +x start_server.sh start_dev.sh test_api.sh setup_environment.sh 2>/dev/null
print_status "Executable permissions set"

# Step 6: Test Spark connection
echo ""
print_info "Step 6: Testing Spark connection..."

# Source environment
source .env

# Test Spark
if python3 -c "
import sys
sys.path.insert(0, '$SPARK_HOME/python')
sys.path.insert(0, '$SPARK_HOME/python/lib/py4j-0.10.9.7-src.zip')
from pyspark.sql import SparkSession
spark = SparkSession.builder.appName('SetupTest').master('local[1]').getOrCreate()
print('Spark connection successful!')
spark.stop()
" 2>/dev/null; then
    print_status "Spark connection test passed"
else
    print_warning "Spark connection test failed, but continuing..."
fi

# Step 7: Final instructions
echo ""
echo "🎉 Setup completed successfully!"
echo ""
print_info "Next steps:"
echo "  1. Start server: ./start_server.sh"
echo "  2. Test API: ./test_api.sh"
echo "  3. View logs: tail -f server.log"
echo ""
print_info "Server will be available at: http://localhost:5000"
print_info "API Documentation: http://localhost:5000/"
print_info "Health Check: http://localhost:5000/health"
echo ""
