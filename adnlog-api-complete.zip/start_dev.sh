#!/bin/bash

echo "🔧 Starting AdnLog API Server (Development Mode)"
echo "=============================================="

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Check if environment file exists
if [ -f ".env" ]; then
    print_status "Loading environment configuration..."
    source .env
else
    print_warning "Environment file not found. Running setup..."
    ./setup_environment.sh
    source .env
fi

# Verify Spark is available
if [ -z "$SPARK_HOME" ] || [ ! -f "$SPARK_HOME/bin/spark-submit" ]; then
    print_error "Spark not properly configured. Please run ./setup_environment.sh first"
    exit 1
fi

print_status "Spark Home: $SPARK_HOME"
print_status "Spark Mode: $SPARK_MODE"

# Check if port 5000 is already in use
if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    print_warning "Port 5000 is already in use!"
    print_info "Checking existing process..."
    
    PID=$(lsof -Pi :5000 -sTCP:LISTEN -t)
    PROCESS=$(ps -p $PID -o comm= 2>/dev/null)
    
    if [ -n "$PROCESS" ]; then
        echo "Process: $PROCESS (PID: $PID)"
        read -p "Kill existing process and continue? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            kill -9 $PID
            print_status "Process killed"
            sleep 2
        else
            print_info "Exiting. Please stop the existing process first."
            exit 1
        fi
    fi
fi

# Start server in development mode
print_info "Starting server in development mode..."
print_info "Features enabled:"
echo "  🔄 Auto-reload on code changes"
echo "  🐛 Debug mode"
echo "  📝 Detailed error messages"
echo ""
print_info "Server will be available at:"
echo "  📍 Local: http://localhost:5000"
echo "  📍 Network: http://$(hostname -I | awk '{print $1}'):5000"
echo "  📖 API Docs: http://localhost:5000/"
echo "  ❤️  Health: http://localhost:5000/health"
echo ""
print_info "Press Ctrl+C to stop the server"
echo ""

# Set Flask environment for development
export FLASK_ENV=development
export FLASK_DEBUG=1

# Start with Python directly (development mode)
exec python3 app.py
