#!/bin/bash

echo "🧪 AdnLog API - Comprehensive Test Suite"
echo "======================================="

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}⚠${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${BLUE}ℹ${NC} $1"
}

# Configuration
API_BASE="http://localhost:5000"
TIMEOUT=30

# Function to test API endpoint
test_endpoint() {
    local name="$1"
    local url="$2"
    local expected_status="$3"
    
    echo ""
    print_info "Testing: $name"
    echo "URL: $url"
    
    # Make request and capture response
    response=$(curl -s -w "\n%{http_code}" --max-time $TIMEOUT "$url" 2>/dev/null)
    
    if [ $? -ne 0 ]; then
        print_error "Request failed (timeout or connection error)"
        return 1
    fi
    
    # Extract status code and body
    status_code=$(echo "$response" | tail -n1)
    body=$(echo "$response" | head -n -1)
    
    # Check status code
    if [ "$status_code" = "$expected_status" ]; then
        print_status "Status: $status_code (Expected: $expected_status)"
        
        # Pretty print JSON if possible
        if command -v python3 &> /dev/null && echo "$body" | python3 -m json.tool >/dev/null 2>&1; then
            echo "$body" | python3 -m json.tool
        else
            echo "$body"
        fi
        
        return 0
    else
        print_error "Status: $status_code (Expected: $expected_status)"
        echo "$body"
        return 1
    fi
}

# Function to check if server is running
check_server() {
    print_info "Checking if server is running..."
    
    if curl -s --max-time 5 "$API_BASE/health" >/dev/null 2>&1; then
        print_status "Server is running"
        return 0
    else
        print_error "Server is not running or not responding"
        print_info "Please start the server first:"
        echo "  Production: ./start_server.sh"
        echo "  Development: ./start_dev.sh"
        return 1
    fi
}

# Main test execution
main() {
    echo ""
    print_info "Starting API tests..."
    
    # Check if server is running
    if ! check_server; then
        exit 1
    fi
    
    # Test counter
    total_tests=0
    passed_tests=0
    
    # Test 1: Health Check
    total_tests=$((total_tests + 1))
    if test_endpoint "Health Check" "$API_BASE/health" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 2: API Documentation
    total_tests=$((total_tests + 1))
    if test_endpoint "API Documentation" "$API_BASE/" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 3: Campaign View Query
    total_tests=$((total_tests + 1))
    if test_endpoint "Campaign View Query" "$API_BASE/query?id_type=campaignId&id=12345&mode=view&from=2024-07-03&to=2024-07-05" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 4: Campaign Click Query
    total_tests=$((total_tests + 1))
    if test_endpoint "Campaign Click Query" "$API_BASE/query?id_type=campaignId&id=12345&mode=click&from=2024-07-03&to=2024-07-05" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 5: Banner View Query
    total_tests=$((total_tests + 1))
    if test_endpoint "Banner View Query" "$API_BASE/query?id_type=bannerId&id=banner1&mode=view&from=2024-07-03&to=2024-07-05" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 6: Banner Click Query
    total_tests=$((total_tests + 1))
    if test_endpoint "Banner Click Query" "$API_BASE/query?id_type=bannerId&id=banner1&mode=click&from=2024-07-03&to=2024-07-05" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 7: Invalid Mode (Error Test)
    total_tests=$((total_tests + 1))
    if test_endpoint "Invalid Mode (Should Fail)" "$API_BASE/query?id_type=campaignId&id=12345&mode=invalid&from=2024-07-03&to=2024-07-05" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 8: Missing Parameters (Error Test)
    total_tests=$((total_tests + 1))
    if test_endpoint "Missing Parameters (Should Fail)" "$API_BASE/query?id_type=campaignId&id=12345" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test 9: Non-existent Campaign
    total_tests=$((total_tests + 1))
    if test_endpoint "Non-existent Campaign" "$API_BASE/query?id_type=campaignId&id=99999&mode=view&from=2024-07-01&to=2024-07-02" "200"; then
        passed_tests=$((passed_tests + 1))
    fi
    
    # Test Summary
    echo ""
    echo "========================================="
    print_info "Test Summary"
    echo "========================================="
    echo "Total Tests: $total_tests"
    echo "Passed: $passed_tests"
    echo "Failed: $((total_tests - passed_tests))"
    
    if [ $passed_tests -eq $total_tests ]; then
        print_status "All tests passed! 🎉"
        echo ""
        print_info "API is working correctly!"
        print_info "Server URL: $API_BASE"
        exit 0
    else
        print_warning "Some tests failed!"
        echo ""
        print_info "Check the server logs for more details:"
        echo "  tail -f logs/error.log"
        exit 1
    fi
}

# Run main function
main "$@"
