# 🚀 AdnLog Analytics API

**Author:** phucnq
**Database:** ClickHouse Cloud
**Purpose:** Compare COUNT(DISTINCT) vs HyperLogLog performance for user counting

## 📋 Overview

This project provides a REST API to analyze user counting performance using two different methods:

1. **COUNT(DISTINCT)** - Exact count, slower but 100% accurate
2. **HyperLogLog** - Approximate count, faster but ~2% error rate

The data is stored in ClickHouse Cloud and includes campaign and banner event data from HDFS.

## 📁 Files

- `api_server.py` - Main API server (Python)
- `dashboard.html` - Web dashboard for testing
- `start_server.sh` - Server startup script
- `README.md` - This documentation

## 🚀 Quick Start

### 1. Start the Server

```bash
# Make the script executable
chmod +x start_server.sh

# Start the server
./start_server.sh
```

### 2. Open Dashboard

Open `dashboard.html` in your web browser to use the interactive dashboard.

### 3. Test API Endpoints

```bash
# Check health
curl "http://localhost:8000/health"

# Get database statistics
curl "http://localhost:8000/stats"

# Compare methods
curl "http://localhost:8000/compare?type=campaign&entity_id=24335&click_or_view=false&start_date=2024-12-01&end_date=2024-12-31"
```

## 📊 API Endpoints

### Health Check
```
GET /health
```
Returns system status and database connection info.

### Database Statistics
```
GET /stats
```
Returns overall database statistics including record counts and date ranges.

### Campaign Analysis

#### COUNT(DISTINCT) Method
```
GET /campaigns/distinct?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31
```

#### HyperLogLog Method
```
GET /campaigns/hll?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31
```

### Banner Analysis

#### COUNT(DISTINCT) Method
```
GET /banners/distinct?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31
```

#### HyperLogLog Method
```
GET /banners/hll?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31
```

### Performance Comparison
```
GET /compare?type=campaign&entity_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31
```

**Parameters:**
- `type`: `campaign` or `banner`
- `entity_id`: Campaign ID or Banner ID
- `click_or_view`: `true` or `false`
- `start_date`: Start date (YYYY-MM-DD)
- `end_date`: End date (YYYY-MM-DD)

## 🔧 Configuration

The ClickHouse Cloud configuration is in `api_server.py`:

```python
CLICKHOUSE_CONFIG = {
    'host': 'ff88qal6fo.germanywestcentral.azure.clickhouse.cloud',
    'port': '8443',
    'username': 'default',
    'password': 'YTxY6~xEOu~u1',
    'url': 'https://ff88qal6fo.germanywestcentral.azure.clickhouse.cloud:8443/'
}
```

## 📈 Performance Comparison

### COUNT(DISTINCT)
- ✅ **Accuracy:** 100% exact count
- ❌ **Speed:** Slower for large datasets
- 🎯 **Use case:** Small to medium datasets, when accuracy is critical

### HyperLogLog (uniqHLL12)
- ⚡ **Speed:** ~10x faster than COUNT(DISTINCT)
- ❌ **Accuracy:** ~2% error rate
- 🎯 **Use case:** Large datasets (>1M records), when speed is important

## 🗄️ Database Schema

### campaign_events
```sql
CREATE TABLE campaign_events (
    campaignId UInt64,
    bannerId UInt64,
    click_or_view String,
    event_date Date,
    guid Int64
) ENGINE = MergeTree()
ORDER BY (event_date, campaignId)
```

### banner_events
```sql
CREATE TABLE banner_events (
    campaignId UInt64,
    bannerId UInt64,
    click_or_view String,
    event_date Date,
    guid Int64
) ENGINE = MergeTree()
ORDER BY (event_date, bannerId)
```

## 🛠️ Requirements

- Python 3.6+
- curl (for ClickHouse queries)
- Internet connection (for ClickHouse Cloud)
- Port 8000 available

## 🔍 Troubleshooting

### Server won't start
1. Check if Python 3 is installed: `python3 --version`
2. Check if port 8000 is free: `lsof -i :8000`
3. Check internet connection

### ClickHouse connection fails
1. Verify credentials in `api_server.py`
2. Check firewall settings
3. Test connection manually:
   ```bash
   curl --user 'default:YTxY6~xEOu~u1' \
        --data-binary 'SELECT 1' \
        'https://ff88qal6fo.germanywestcentral.azure.clickhouse.cloud:8443/'
   ```

### Dashboard not working
1. Make sure the API server is running on port 8000
2. Open browser developer tools to check for errors
3. Verify CORS is enabled (already configured in the server)

## 📝 Example Usage

```bash
# Start server
./start_server.sh

# Test with real data
curl "http://localhost:8000/compare?type=campaign&entity_id=24335&click_or_view=false&start_date=2024-12-01&end_date=2024-12-31"
```

Expected response:
```json
{
  "comparison": {
    "entity_type": "campaign",
    "entity_id": 24335,
    "click_or_view": "false",
    "date_range": {
      "start_date": "2024-12-01",
      "end_date": "2024-12-31"
    }
  },
  "results": {
    "distinct_method": {
      "count": 1234,
      "description": "Exact count using COUNT(DISTINCT guid)"
    },
    "hyperloglog_method": {
      "count": 1228,
      "description": "Approximate count using uniqHLL12(guid)"
    }
  },
  "performance": {
    "execution_time_ms": 45.67,
    "error_rate_percent": 0.49,
    "absolute_difference": 6,
    "recommendation": "Use COUNT(DISTINCT) for smaller datasets"
  }
}
```

## 🎯 Project Goals

1. ✅ Load data from HDFS to ClickHouse Cloud
2. ✅ Create REST API for user counting
3. ✅ Compare COUNT(DISTINCT) vs HyperLogLog performance
4. ✅ Provide web dashboard for easy testing
5. ✅ Document performance characteristics

---

**Happy analyzing! 🚀📊**

- ✅ Truy vấn số user view/click theo Campaign ID
- ✅ Truy vấn số user view/click theo Banner ID  
- ✅ Lọc theo khoảng thời gian (từ ngày A đến ngày B)
- ✅ Sử dụng thuật toán HyperLogLog để tối ưu hiệu suất
- ✅ Thời gian phản hồi < 1 phút
- ✅ Web interface và RESTful API
- ✅ Health check endpoint

## Cấu trúc dự án

```
.
├── app.py                 # Main Flask application
├── config.py             # Configuration settings
├── init_database.py      # Database initialization script
├── requirements.txt      # Python dependencies
├── Dockerfile           # Docker configuration
├── docker-compose.yml   # Docker Compose setup
├── templates/
│   └── index.html       # Web interface
├── databasse.sql        # SQL schema reference
└── README.md           # This file
```

## Cài đặt và chạy

### Phương pháp 1: Chạy với Docker (Khuyến nghị)

1. **Build và chạy với Docker Compose:**
```bash
docker-compose up --build
```

2. **Khởi tạo database:**
```bash
docker-compose exec adnlog-api python init_database.py
```

3. **Truy cập ứng dụng:**
- Web interface: http://localhost:5000
- API health check: http://localhost:5000/api/health

### Phương pháp 2: Chạy local

1. **Cài đặt dependencies:**
```bash
pip install -r requirements.txt
```

2. **Cấu hình ClickHouse:**
```bash
export CLICKHOUSE_HOST=localhost
export CLICKHOUSE_PORT=8123
export CLICKHOUSE_USER=default
export CLICKHOUSE_PASSWORD=
```

3. **Khởi tạo database:**
```bash
python init_database.py
```

4. **Chạy server:**
```bash
python app.py
```

## API Endpoints

### 1. Health Check
```
GET /api/health
```

### 2. Banner Statistics
```
GET /api/stats/banner/{banner_id}?action={view|click}&start_date={YYYY-MM-DD}&end_date={YYYY-MM-DD}
```

**Ví dụ:**
```bash
curl "http://localhost:5000/api/stats/banner/2001?action=view&start_date=2024-01-01&end_date=2024-01-31"
```

### 3. Campaign Statistics  
```
GET /api/stats/campaign/{campaign_id}?action={view|click}&start_date={YYYY-MM-DD}&end_date={YYYY-MM-DD}
```

**Ví dụ:**
```bash
curl "http://localhost:5000/api/stats/campaign/1001?action=click&start_date=2024-01-01&end_date=2024-01-31"
```

## Cấu hình Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| CLICKHOUSE_HOST | localhost | ClickHouse server host |
| CLICKHOUSE_PORT | 8123 | ClickHouse server port |
| CLICKHOUSE_USER | default | ClickHouse username |
| CLICKHOUSE_PASSWORD | | ClickHouse password |
| CLICKHOUSE_DATABASE | adnlog_db | Database name |
| HOST | 0.0.0.0 | Flask server host |
| PORT | 5000 | Flask server port |

## Deployment trên Teleport

### 1. Chuẩn bị file nén
```bash
# Tạo file nén để upload lên teleport
tar -czf adnlog-server.tar.gz *.py *.txt *.yml *.md templates/ Dockerfile
```

### 2. Upload và giải nén trên server
```bash
# Trên teleport server
tar -xzf adnlog-server.tar.gz
cd adnlog-server/
```

### 3. Chạy với Docker
```bash
# Build và chạy
docker-compose up --build -d

# Khởi tạo database
docker-compose exec adnlog-api python init_database.py
```

### 4. Kiểm tra hoạt động
```bash
# Health check
curl http://localhost:5000/api/health

# Test API
curl "http://localhost:5000/api/stats/banner/2001?action=view&start_date=2024-01-01&end_date=2024-01-31"
```

## Cấu trúc Database

### Database: adnlog_db

#### Table: campaign_events
```sql
CREATE TABLE campaign_events (
    campaignId UInt64,
    click_or_view Boolean,  -- false: view, true: click
    event_date Date,
    guid UInt64
) ENGINE = MergeTree()
ORDER BY (event_date, campaignId);
```

#### Table: banner_events  
```sql
CREATE TABLE banner_events (
    bannerId UInt64,
    click_or_view Boolean,  -- false: view, true: click
    event_date Date,
    guid UInt64
) ENGINE = MergeTree()
ORDER BY (event_date, bannerId);
```

## Tối ưu hiệu suất

- Sử dụng thuật toán **HyperLogLog** (`uniqHLL12`) để đếm unique users
- Index theo `(event_date, campaignId/bannerId)` để tối ưu query theo thời gian
- Connection pooling và timeout handling
- Parameterized queries để tránh SQL injection

## Troubleshooting

### Lỗi kết nối ClickHouse
```bash
# Kiểm tra ClickHouse đang chạy
docker-compose ps

# Xem logs
docker-compose logs clickhouse
docker-compose logs adnlog-api
```

### Lỗi timeout
- Tăng `CLICKHOUSE_SEND_RECEIVE_TIMEOUT` trong environment variables
- Kiểm tra performance của ClickHouse server

## Liên hệ

- Developer: phucnq
- Team: phuongtl
- Project: AdnLog Analytics API
