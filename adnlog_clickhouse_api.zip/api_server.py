#!/usr/bin/env python3
"""
AdnLog Analytics API Server - ClickHouse Cloud
Author: phucnq
Purpose: Compare COUNT(DISTINCT) vs HyperLogLog performance for user counting
Database: ClickHouse Cloud
"""

import http.server
import socketserver
import urllib.parse
import subprocess
import json
import time
import sys

# ClickHouse Cloud Configuration
CLICKHOUSE_CONFIG = {
    'host': 'ff88qal6fo.germanywestcentral.azure.clickhouse.cloud',
    'port': '8443',
    'username': 'default',
    'password': 'YTxY6~xEOu~u1',
    'url': 'https://ff88qal6fo.germanywestcentral.azure.clickhouse.cloud:8443/'
}

class AnalyticsAPIHandler(http.server.BaseHTTPRequestHandler):
    
    def execute_clickhouse_query(self, query):
        """Execute query on ClickHouse Cloud"""
        try:
            cmd = [
                "curl", "-s", "--user", 
                f"{CLICKHOUSE_CONFIG['username']}:{CLICKHOUSE_CONFIG['password']}",
                "--data-binary", query,
                CLICKHOUSE_CONFIG['url']
            ]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return result.stdout.strip()
        except subprocess.TimeoutExpired:
            return "TIMEOUT"
        except Exception as e:
            return f"ERROR: {str(e)}"
    
    def log_message(self, format, *args):
        """Override to reduce log noise"""
        pass
    
    def do_GET(self):
        path = self.path
        parsed_url = urllib.parse.urlparse(path)
        query_params = urllib.parse.parse_qs(parsed_url.query)
        
        # CORS headers
        self.send_response(200)
        self.send_header("Content-type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        
        try:
            if path == "/" or path == "/api":
                response = {
                    "message": "🚀 AdnLog Analytics API - ClickHouse Cloud",
                    "version": "1.0.0",
                    "author": "phucnq",
                    "database": "ClickHouse Cloud",
                    "endpoints": {
                        "health": "/health - Check system status",
                        "stats": "/stats - Database statistics",
                        "campaigns": {
                            "distinct": "/campaigns/distinct?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31",
                            "hll": "/campaigns/hll?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31"
                        },
                        "banners": {
                            "distinct": "/banners/distinct?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31",
                            "hll": "/banners/hll?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31"
                        },
                        "compare": "/compare?type=campaign&entity_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31"
                    },
                    "usage": {
                        "distinct_method": "Exact count using COUNT(DISTINCT guid) - slower but 100% accurate",
                        "hll_method": "Approximate count using uniqHLL12(guid) - faster but ~2% error rate"
                    }
                }
                
            elif path == "/health":
                campaign_count = self.execute_clickhouse_query("SELECT COUNT(*) FROM campaign_events")
                banner_count = self.execute_clickhouse_query("SELECT COUNT(*) FROM banner_events")
                
                response = {
                    "status": "healthy" if campaign_count.isdigit() else "error",
                    "database": "ClickHouse Cloud",
                    "host": CLICKHOUSE_CONFIG['host'],
                    "tables": {
                        "campaign_events": f"{int(campaign_count):,}" if campaign_count.isdigit() else campaign_count,
                        "banner_events": f"{int(banner_count):,}" if banner_count.isdigit() else banner_count
                    },
                    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
                }
                
            elif path == "/stats":
                stats_query = """
                SELECT 
                    COUNT(*) as total_records,
                    COUNT(DISTINCT campaignId) as unique_campaigns,
                    COUNT(DISTINCT bannerId) as unique_banners,
                    COUNT(DISTINCT guid) as unique_guids,
                    MIN(event_date) as min_date,
                    MAX(event_date) as max_date
                FROM campaign_events
                FORMAT JSON
                """
                
                result = self.execute_clickhouse_query(stats_query)
                try:
                    stats_data = json.loads(result)
                    if stats_data.get('rows', 0) > 0:
                        stats = stats_data['data'][0]
                        response = {
                            "database_statistics": {
                                "total_records": f"{stats['total_records']:,}",
                                "unique_campaigns": f"{stats['unique_campaigns']:,}",
                                "unique_banners": f"{stats['unique_banners']:,}",
                                "unique_guids": f"{stats['unique_guids']:,}",
                                "date_range": {
                                    "min_date": stats['min_date'],
                                    "max_date": stats['max_date']
                                }
                            },
                            "performance_recommendations": {
                                "small_datasets": "Use COUNT(DISTINCT) for datasets < 1M records",
                                "large_datasets": "Use HyperLogLog for datasets > 1M records",
                                "accuracy_vs_speed": "HyperLogLog is ~10x faster with ~2% error rate"
                            }
                        }
                    else:
                        response = {"error": "No data found in database"}
                except json.JSONDecodeError:
                    response = {"error": "Failed to parse statistics", "raw_result": result}
                    
            elif "/campaigns/distinct" in path:
                campaign_id = query_params.get("campaign_id", [""])[0]
                click_or_view = query_params.get("click_or_view", ["true"])[0]
                start_date = query_params.get("start_date", ["2024-01-01"])[0]
                end_date = query_params.get("end_date", ["2024-12-31"])[0]
                
                if not campaign_id:
                    response = {"error": "campaign_id parameter is required"}
                else:
                    start_time = time.time()
                    
                    query = f"""
                    SELECT campaignId, click_or_view, count(DISTINCT guid) as user_count
                    FROM campaign_events
                    WHERE event_date BETWEEN '{start_date}' AND '{end_date}'
                          AND click_or_view = '{click_or_view}'
                          AND campaignId = {campaign_id}
                    GROUP BY campaignId, click_or_view
                    FORMAT JSON
                    """
                    
                    result = self.execute_clickhouse_query(query)
                    execution_time = round((time.time() - start_time) * 1000, 2)
                    
                    try:
                        data = json.loads(result)
                        if data.get('rows', 0) > 0:
                            row = data['data'][0]
                            response = {
                                "method": "COUNT(DISTINCT)",
                                "campaignId": row['campaignId'],
                                "click_or_view": row['click_or_view'],
                                "user_count": row['user_count'],
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "description": "Exact count - slower but 100% accurate",
                                "query": query.strip()
                            }
                        else:
                            response = {
                                "method": "COUNT(DISTINCT)",
                                "campaignId": int(campaign_id),
                                "click_or_view": click_or_view,
                                "user_count": 0,
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "message": "No data found for specified criteria"
                            }
                    except json.JSONDecodeError:
                        response = {"error": "Failed to parse result", "raw_result": result}
                        
            elif "/campaigns/hll" in path:
                campaign_id = query_params.get("campaign_id", [""])[0]
                click_or_view = query_params.get("click_or_view", ["true"])[0]
                start_date = query_params.get("start_date", ["2024-01-01"])[0]
                end_date = query_params.get("end_date", ["2024-12-31"])[0]
                
                if not campaign_id:
                    response = {"error": "campaign_id parameter is required"}
                else:
                    start_time = time.time()
                    
                    query = f"""
                    SELECT campaignId, click_or_view, uniqHLL12(guid) as estimated_user_count
                    FROM campaign_events
                    WHERE event_date BETWEEN '{start_date}' AND '{end_date}'
                          AND click_or_view = '{click_or_view}'
                          AND campaignId = {campaign_id}
                    GROUP BY campaignId, click_or_view
                    FORMAT JSON
                    """
                    
                    result = self.execute_clickhouse_query(query)
                    execution_time = round((time.time() - start_time) * 1000, 2)
                    
                    try:
                        data = json.loads(result)
                        if data.get('rows', 0) > 0:
                            row = data['data'][0]
                            response = {
                                "method": "HyperLogLog",
                                "campaignId": row['campaignId'],
                                "click_or_view": row['click_or_view'],
                                "estimated_user_count": row['estimated_user_count'],
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "description": "Approximate count - faster but ~2% error rate",
                                "query": query.strip()
                            }
                        else:
                            response = {
                                "method": "HyperLogLog",
                                "campaignId": int(campaign_id),
                                "click_or_view": click_or_view,
                                "estimated_user_count": 0,
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "message": "No data found for specified criteria"
                            }
                    except json.JSONDecodeError:
                        response = {"error": "Failed to parse result", "raw_result": result}

            elif "/banners/distinct" in path:
                banner_id = query_params.get("banner_id", [""])[0]
                click_or_view = query_params.get("click_or_view", ["true"])[0]
                start_date = query_params.get("start_date", ["2024-01-01"])[0]
                end_date = query_params.get("end_date", ["2024-12-31"])[0]

                if not banner_id:
                    response = {"error": "banner_id parameter is required"}
                else:
                    start_time = time.time()

                    query = f"""
                    SELECT bannerId, click_or_view, count(DISTINCT guid) as user_count
                    FROM banner_events
                    WHERE event_date BETWEEN '{start_date}' AND '{end_date}'
                          AND click_or_view = '{click_or_view}'
                          AND bannerId = {banner_id}
                    GROUP BY bannerId, click_or_view
                    FORMAT JSON
                    """

                    result = self.execute_clickhouse_query(query)
                    execution_time = round((time.time() - start_time) * 1000, 2)

                    try:
                        data = json.loads(result)
                        if data.get('rows', 0) > 0:
                            row = data['data'][0]
                            response = {
                                "method": "COUNT(DISTINCT)",
                                "bannerId": row['bannerId'],
                                "click_or_view": row['click_or_view'],
                                "user_count": row['user_count'],
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "description": "Exact count - slower but 100% accurate"
                            }
                        else:
                            response = {
                                "method": "COUNT(DISTINCT)",
                                "bannerId": int(banner_id),
                                "click_or_view": click_or_view,
                                "user_count": 0,
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date}
                            }
                    except json.JSONDecodeError:
                        response = {"error": "Failed to parse result", "raw_result": result}

            elif "/banners/hll" in path:
                banner_id = query_params.get("banner_id", [""])[0]
                click_or_view = query_params.get("click_or_view", ["true"])[0]
                start_date = query_params.get("start_date", ["2024-01-01"])[0]
                end_date = query_params.get("end_date", ["2024-12-31"])[0]

                if not banner_id:
                    response = {"error": "banner_id parameter is required"}
                else:
                    start_time = time.time()

                    query = f"""
                    SELECT bannerId, click_or_view, uniqHLL12(guid) as estimated_user_count
                    FROM banner_events
                    WHERE event_date BETWEEN '{start_date}' AND '{end_date}'
                          AND click_or_view = '{click_or_view}'
                          AND bannerId = {banner_id}
                    GROUP BY bannerId, click_or_view
                    FORMAT JSON
                    """

                    result = self.execute_clickhouse_query(query)
                    execution_time = round((time.time() - start_time) * 1000, 2)

                    try:
                        data = json.loads(result)
                        if data.get('rows', 0) > 0:
                            row = data['data'][0]
                            response = {
                                "method": "HyperLogLog",
                                "bannerId": row['bannerId'],
                                "click_or_view": row['click_or_view'],
                                "estimated_user_count": row['estimated_user_count'],
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date},
                                "description": "Approximate count - faster but ~2% error rate"
                            }
                        else:
                            response = {
                                "method": "HyperLogLog",
                                "bannerId": int(banner_id),
                                "click_or_view": click_or_view,
                                "estimated_user_count": 0,
                                "execution_time_ms": execution_time,
                                "date_range": {"start_date": start_date, "end_date": end_date}
                            }
                    except json.JSONDecodeError:
                        response = {"error": "Failed to parse result", "raw_result": result}

            elif "/compare" in path:
                entity_type = query_params.get("type", ["campaign"])[0]  # campaign or banner
                entity_id = query_params.get("entity_id", [""])[0]
                click_or_view = query_params.get("click_or_view", ["true"])[0]
                start_date = query_params.get("start_date", ["2024-01-01"])[0]
                end_date = query_params.get("end_date", ["2024-12-31"])[0]

                if not entity_id:
                    response = {"error": "entity_id parameter is required"}
                else:
                    if entity_type == "campaign":
                        table_name = "campaign_events"
                        id_field = "campaignId"
                    else:
                        table_name = "banner_events"
                        id_field = "bannerId"

                    start_time = time.time()

                    query = f"""
                    SELECT
                        {id_field},
                        click_or_view,
                        COUNT(DISTINCT guid) as distinct_count,
                        uniqHLL12(guid) as hll_count
                    FROM {table_name}
                    WHERE event_date BETWEEN '{start_date}' AND '{end_date}'
                          AND click_or_view = '{click_or_view}'
                          AND {id_field} = {entity_id}
                    GROUP BY {id_field}, click_or_view
                    FORMAT JSON
                    """

                    result = self.execute_clickhouse_query(query)
                    execution_time = round((time.time() - start_time) * 1000, 2)

                    try:
                        data = json.loads(result)
                        if data.get('rows', 0) > 0:
                            row = data['data'][0]
                            distinct_count = row['distinct_count']
                            hll_count = row['hll_count']

                            error_rate = abs(hll_count - distinct_count) / distinct_count * 100 if distinct_count > 0 else 0

                            response = {
                                "comparison": {
                                    "entity_type": entity_type,
                                    "entity_id": row[id_field],
                                    "click_or_view": row['click_or_view'],
                                    "date_range": {"start_date": start_date, "end_date": end_date}
                                },
                                "results": {
                                    "distinct_method": {
                                        "count": distinct_count,
                                        "description": "Exact count using COUNT(DISTINCT guid)"
                                    },
                                    "hyperloglog_method": {
                                        "count": hll_count,
                                        "description": "Approximate count using uniqHLL12(guid)"
                                    }
                                },
                                "performance": {
                                    "execution_time_ms": execution_time,
                                    "error_rate_percent": round(error_rate, 2),
                                    "absolute_difference": abs(hll_count - distinct_count),
                                    "recommendation": "Use HyperLogLog for large datasets (>1M records)" if distinct_count > 1000000 else "Use COUNT(DISTINCT) for smaller datasets"
                                }
                            }
                        else:
                            response = {"message": "No data found for the specified criteria"}
                    except json.JSONDecodeError:
                        response = {"error": "Failed to parse result", "raw_result": result}

            else:
                response = {
                    "error": "Endpoint not found",
                    "available_endpoints": ["/", "/health", "/stats", "/campaigns/distinct", "/campaigns/hll", "/banners/distinct", "/banners/hll", "/compare"]
                }

        except Exception as e:
            response = {"error": f"Server error: {str(e)}"}

        self.wfile.write(json.dumps(response, indent=2).encode())

    def do_OPTIONS(self):
        """Handle CORS preflight requests"""
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

def main():
    PORT = 8000

    print("🚀 AdnLog Analytics API Server")
    print("=" * 50)
    print(f"📊 Database: ClickHouse Cloud")
    print(f"🌐 Host: {CLICKHOUSE_CONFIG['host']}")
    print(f"👤 Author: phucnq")
    print(f"🔗 API URL: http://localhost:{PORT}")
    print(f"📱 Dashboard: Open dashboard.html in browser")
    print("=" * 50)
    print("\n📋 Available endpoints:")
    print("  GET /health - System status")
    print("  GET /stats - Database statistics")
    print("  GET /campaigns/distinct?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31")
    print("  GET /campaigns/hll?campaign_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31")
    print("  GET /banners/distinct?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31")
    print("  GET /banners/hll?banner_id=456&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31")
    print("  GET /compare?type=campaign&entity_id=123&click_or_view=true&start_date=2024-01-01&end_date=2024-12-31")
    print("\n🚀 Starting server...")

    try:
        with socketserver.TCPServer(("", PORT), AnalyticsAPIHandler) as httpd:
            print(f"✅ Server running on http://localhost:{PORT}")
            print("Press Ctrl+C to stop")
            httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Server error: {e}")

if __name__ == "__main__":
    main()
