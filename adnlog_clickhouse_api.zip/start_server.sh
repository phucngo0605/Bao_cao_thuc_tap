#!/bin/bash

# AdnLog Analytics API Server Startup Script
# Author: phucnq

echo "🚀 AdnLog Analytics API Server"
echo "================================"
echo "📊 Database: ClickHouse Cloud"
echo "👤 Author: phucnq"
echo "📅 Date: $(date)"
echo "================================"

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed or not in PATH"
    echo "Please install Python 3 to run this server"
    exit 1
fi

echo "✅ Python 3 found: $(python3 --version)"

# Check if curl is available (needed for ClickHouse queries)
if ! command -v curl &> /dev/null; then
    echo "❌ curl is not installed or not in PATH"
    echo "Please install curl to connect to ClickHouse Cloud"
    exit 1
fi

echo "✅ curl found: $(curl --version | head -1)"

# Test ClickHouse connection
echo ""
echo "🔍 Testing ClickHouse Cloud connection..."
CLICKHOUSE_TEST=$(curl -s --user 'default:YTxY6~xEOu~u1' \
                       --data-binary 'SELECT 1' \
                       'https://ff88qal6fo.germanywestcentral.azure.clickhouse.cloud:8443/' \
                       --max-time 10)

if [ "$CLICKHOUSE_TEST" = "1" ]; then
    echo "✅ ClickHouse Cloud connection successful"
else
    echo "❌ ClickHouse Cloud connection failed"
    echo "Response: $CLICKHOUSE_TEST"
    echo ""
    echo "Please check:"
    echo "1. Internet connection"
    echo "2. ClickHouse Cloud credentials"
    echo "3. Firewall settings"
    exit 1
fi

# Check if port 8000 is available
if lsof -Pi :8000 -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo "⚠️  Port 8000 is already in use"
    echo "Please stop the existing service or use a different port"
    echo ""
    echo "To find what's using port 8000:"
    echo "  lsof -i :8000"
    echo ""
    echo "To kill the process:"
    echo "  kill \$(lsof -t -i:8000)"
    exit 1
fi

echo "✅ Port 8000 is available"

# Start the API server
echo ""
echo "🚀 Starting AdnLog Analytics API Server..."
echo "📱 Dashboard: Open dashboard.html in your browser"
echo "🔗 API URL: http://localhost:8000"
echo ""
echo "Press Ctrl+C to stop the server"
echo "================================"

# Run the Python API server
python3 api_server.py
